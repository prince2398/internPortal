        <br><br>
        <footer class="footer bg-secondary fixed-bottom">
          <div class="footer-copyright text-center py-3">© 2018 Copyright:
            <a class="text-dark" href="">Internship Portal</a>
          </div>
        </footer>
