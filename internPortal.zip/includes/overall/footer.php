    <?php include("includes/footer.php"); ?>
    <?php include("includes/scripts.php"); ?>
  </body>
</html>
