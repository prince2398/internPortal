<?php require_once("core/init.php") ?>
<!doctype html>
<html lang="en">
  <?php include("includes/head.php"); ?>

  <body style="padding-top: 5rem;">
    <?php include("includes/header.php"); ?>

