<?php
    define("DBHOST",'localhost');
    define("DBUSER",'root');
    define("DBPASSWORD",'Prince2398');
    define("DBNAME", 'intern');
    define("HOME",'/internPortal');

    $errors = array();
?>
