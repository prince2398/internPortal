<?php
    error_reporting(1);
    session_start();
    require "core.php";

    require "database/connect.php";
    require "functions/general.php";
    require "functions/employer.php";
    require "functions/student.php";


?>
