Minimal Internship Portal using Bootstrap and core PHP
